using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameStats
{
    static public int score = 0;
    static public float timer = 0.0f;

    static public bool gameRunning = false;
}
